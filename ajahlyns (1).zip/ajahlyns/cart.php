<?php include('connect.php'); 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cartID = $_POST['id'];
    $result = mysqli_query($db,"DELETE FROM carts WHERE CartID = '$cartID'");
    if($result == true) {   
        header('location: cart.php');
    }
}
?>

<!DOCTYPE html>
<html lang="en">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Ajahlyn's Eatery Online Ordery System</title>
    <link rel="stylesheet" href="style.css">

    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <!-- custom css file link  -->
</head>
<body>
    
<!-- header section starts-->

<header>

    <a href="#" class="logo"><i class="fas fa-utensils"></i>Ajahlyn's Eatery</a>
    <div>
        <form action="connect.php" method="post"></form>
    </div>

    <nav class="navbar">
        <a class="active" href="index.php#home">home</a>
        <a href="index.php#dishes">dishes</a>
        <a href="index.php#about">about</a>
        <a href="index.php#menu">menu</a>
        <a href="index.php#order">order</a>
    </nav>

    <div class="icons">
        <i class="fas fa-bars" id="menu-bars"></i>
        <a href="cart.php" class="fas fa-shopping-cart"></a>
    </div>

</header>

<!-- header section ends-->

<!-- search form  -->

<form action="" id="search-form">
    <input type="search" placeholder="search mo boss..." name="" id="search-box">
    <label for="search-box" class="fas fa-search"></label>
    <i class="fas fa-times" id="close"></i>
</form>

<!-- home section starts  -->

<section class="home" id="home">

</section>

<!-- home section ends -->

<!-- Carts -->

<section class="dishes" id="dishes">

    <h1 class="sub-heading"> MY CART </h1>

    <div class="box-container">
    <?php
        $query = $db -> query('SELECT * FROM carts');
        $product = $query -> fetch_all(MYSQLI_ASSOC);
    ?>
    <?php foreach ($product as $cart) : ?>
        <div class="box">
            <form action="delete.php" method="POST">
            <a href="#" class="fas fa-heart"></a>
            <a href="#" class="fas fa-eye"></a>
            <img src='<?php echo $cart['Image']; ?>'/>
            <h3><?= $cart['ProductName']?></h3>
            <span>₱<?= $cart['Price']?></span>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <input type="hidden" name= "id" class="btn" value="<?php echo $cart['CartID']; ?>">
            <input class="btn" type="submit" name="submit" value="Delete"> 
            </form>
        </div>
    <?php endforeach; ?>
    </div>
    

</section>

<!-- Orders  -->

<section class="dishes" id="dishes">

    <h1 class="sub-heading"> MY ORDER</h1><br>
    <?php
    
    if (isset($_POST['buy']))
    {   
        $result = mysqli_query($db, 'SELECT * FROM orders');
        $row = mysqli_fetch_array($result);
        if($row)
        {
            mysqli_query($db, 'TRUNCATE table orders');
            header('location: index.php');
        }
        else
        {
            echo "No results!";
        }
    } 
    ?>
    
    <button type="button" name= "buy" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Buy All</button>
  <!-- Modal -->
    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog"> 
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
            <form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
            <button type="button"  name="buy" class="close" data-dismiss="modal">&times;</button>
            </form>
            </div>
            <div class="modal-body">
            <p>Succesfully Ordered</p>
            </div>
            <div class="modal-footer">        
            </div>
        </div>
        
        </div>
    </div>
    <div class="box-container">
    <?php
        $query = $db -> query('SELECT * FROM orders');
        $products = $query -> fetch_all(MYSQLI_ASSOC);
    ?>
    <?php foreach ($products as $order) : ?>       
        <div class="box">
            <form action="delete.php" method="POST">
            <div class="image">
                <img src='<?php echo $order['Image']; ?>'/>
            </div>
            <div class="content">
                <label >Product Name :</label><br>  
                <h3><?= $order['OrderName']?></h3><br>
                <label >Customer Name :</label><br>  
                <span><?= $order['CustomerName']?></span><br>
                <label >Quantity :</label><br>  
                <span><?= $order['Quantity']?></span><br>
                <label >Address :</label><br>  
                <span><?= $order['Address']?></span><br>
                <label >Contact Number :</label><br>  
                <span><?= $order['ContactNumber']?></span><br>
                <label >Date :</label><br>
                <span><?= $order['Date']?></span><br>
                <label >Message :</label><br>   
                <textarea  cols="25" rows="2" readonly><?= $order['Message']?></textarea><br><br> 
                <span class="price"><?php echo $order['Price']; ?></span><br>
                <input type="hidden" name= "id" class="btn" value="<?php echo $order['OrderID']; ?>">
                <input class="btn" type="submit" name="submits" value="Delete">
            </form>
            </div>
        </div>
    <?php endforeach; ?>
    </div>
</section>

<!-- dishes section ends -->

<!-- about section starts  -->

<section class="about" id="about">

   
</section>

<!-- about section ends -->

<!-- menu section starts  -->

<section class="menu" id="menu">

    

</section>

<!-- order section ends -->

<!-- footer section starts  -->

<section class="footer">

    <div class="box-container">

        <div class="box">
            <h3>locations</h3>
            <a href="#">butong</a>
            <a href="#">muzon</a>
            <a href="#">kumintang</a>
            <a href="#">taal</a>
            <a href="#">balagtas</a>
        </div>

        <div class="box">
            <h3>quick links</h3>
            <a href="#">home</a>
            <a href="#">dishes</a>
            <a href="#">about</a>
            <a href="#">menu</a>
            <a href="#">reivew</a>
            <a href="#">order</a>
        </div>

        <div class="box">
            <h3>contact info</h3>
            <a href="#">09125398422</a>
            <a href="#">09758776327</a>
            <a href="#">ajahlyns_eatery@gmail.com</a>
            <a href="#">ajahlynseatery@gmail.com</a>
            <a href="#">Golden Country Homes, Brgy. Alangilan, Batangas City 4200</a>
        </div>

        <div class="box">
            <h3>follow us</h3>
            <a href="#">facebook</a>
            <a href="#">twitter</a>
            <a href="#">instagram</a>
            <a href="#">linkedin</a>
        </div>

    </div>

    <div class="credit"> copyright @ 2022 by <span>QWERTY</span> </div>

</section>

<!-- footer section ends -->

<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="script.js"></script>

</body>
</html>