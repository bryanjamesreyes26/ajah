<?php
    $servername = "localhost";
	$username = "root";
	$password = "";
	$database = "ajahlyn";

    $db = mysqli_connect('localhost', 'root', '', 'ajahlyn');
    if (mysqli_connect_errno())
        {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
        }