<?php
include('connect.php');

if(isset($_POST['submits'])) {
    $cust = mysqli_real_escape_string($db, $_POST['customername']);
    $ordername = mysqli_real_escape_string($db, $_POST['order']);
    $quan = mysqli_real_escape_string($db, $_POST['quantity']);
    $add = mysqli_real_escape_string($db, $_POST['address']);
    $contNum = mysqli_real_escape_string($db, $_POST['contactnumber']);
    $extOrd= mysqli_real_escape_string($db, $_POST['extrafood']);
    $date = mysqli_real_escape_string($db, $_POST['date']);
    $mess = mysqli_real_escape_string($db, $_POST['message']);
    $query = "SELECT * FROM popular WHERE Product_Name = '$ordername'";
    $result = mysqli_query($db,$query);
    $row = mysqli_fetch_array($result);

    $querys = "SELECT * FROM specialty WHERE Product_Name = '$ordername'";
    $results = mysqli_query($db,$querys);
    $rows = mysqli_fetch_array($results);

    if($rows == true) {
        $price = $rows['Price'];
        $img = $rows['Image'];
        $tprice = $quan * $price;
        $sql = "INSERT INTO orders (CustomerName, OrderName, Quantity, Address, ContactNumber, ExtraOrder, Date, Message, Image, Price) VALUES ('$cust', '$ordername', '$quan', '$add', '$contNum', '$extOrd', '$date', '$mess','$img', '$tprice')";
        $results = mysqli_query($db,$sql);
        header('location: index.php');
    }   
    if($row == true) {
        $price = $row['Price'];
        $img = $row['Image'];
        $tprice = $quan * $price;
        $sql = "INSERT INTO orders (CustomerName, OrderName, Quantity, Address, ContactNumber, ExtraOrder, Date, Message, Image, Price) VALUES ('$cust', '$ordername', '$quan', '$add', '$contNum', '$extOrd', '$date', '$mess','$img', '$tprice')";
        $results = mysqli_query($db,$sql);
        header('location: index.php');
    }

    else {
        mysqli_error($db);
        header('location: index.php?NoRecipeFound');
    }
}


