<?php include('connect.php'); ?>

<!DOCTYPE html>
<html lang="en">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Ajahlyn's Eatery Online Ordery System</title>
    <link rel="stylesheet" href="style.css">

    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <!-- custom css file link  -->
</head>
<body>
    
<!-- header section starts-->

<header>

    <a href="#" class="logo"><i class="fas fa-utensils"></i>Ajahlyn's Eatery</a>
    <div>
        <form action="connect.php" method="post"></form>
    </div>

    <nav class="navbar">
        <a class="active" href="#home">home</a>
        <a href="#dishes">dishes</a>
        <a href="#about">about</a>
        <a href="#menu">menu</a>
        <a href="#order">order</a>
    </nav>

    <div class="icons">
        <i class="fas fa-bars" id="menu-bars"></i>
        <i class="fas fa-search" id="search-icon"></i>
        <a href="#" class="fas fa-heart"></a>
        <a href="cart.php" class="fas fa-shopping-cart"></a>
    </div>

</header>

<!-- header section ends-->

<!-- search form  -->

<form action="" id="search-form">
    <input type="search" placeholder="search mo boss..." name="" id="search-box">
    <label for="search-box" class="fas fa-search"></label>
    <i class="fas fa-times" id="close"></i>
</form>

<!-- home section starts  -->

<section class="home" id="home">

    <div class="swiper-container home-slider">

        <div class="swiper-wrapper wrapper">
            <div class="swiper-slide slide">
                <div class="content">
                    <span>our special dish</span>
                    <h3>Fried Chicken</h3>
                    <p>The overall flavor caters to the Filipino palette. It has a hint of “toyomansi”, and can be flavorful despite the short marinating time.</p>
                    <a href="#" class="btn">order now</a>
                </div>
                <div class="image">
                    <img src="images/friedchicken.jpg" alt="">
                </div>
            </div>

            <div class="swiper-slide slide">
                <div class="content">
                    <span>our special dish</span>
                    <h3>Pork Tapa</h3>
                    <p>A preserved meat dish that can be enjoyed by all people.</p>
                    <a href="#" class="btn">order now</a>
                </div>
                <div class="image">
                    <img src="images/porktapa.jpg" alt="">
                </div>
            </div>

            <div class="swiper-slide slide">
                <div class="content">
                    <span>our special dish</span>
                    <h3>Pork Tocino</h3>
                    <p>Preserved pork cutlets with a sweet-salty condiments as seasoning.</p>
                    <a href="#" class="btn">order now</a>
                </div>
                <div class="image">
                    <img src="images/porktocino.png" alt="">
                </div>
            </div>

        </div>

        <div class="swiper-pagination"></div>

    </div>

</section>

<!-- home section ends -->

<!-- dishes section starts  -->

<section class="dishes" id="dishes">

    <h3 class="sub-heading"> Popular Dishes </h3>
    <h1 class="heading"> Silog Meals </h1>

    <div class="box-container">
        <?php $query =  $db -> query('SELECT * FROM popular');
        $product = $query -> fetch_all(MYSQLI_ASSOC);
        ?>
        <?php foreach($product as $products) :?>
        <div class="box">    
            <form action="addtocart.php" method="POST">
            <a href="#" class="fas fa-heart"></a>
            <a href="#" class="fas fa-eye"></a>
            <img src='<?php echo $products['Image']; ?>'/>
            <h3><?= $products['Product_Name']; ?></h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <span>₱<?= $products['Price']?></span><br>
            <input class="btn" type="hidden" name="id" value="<?php echo $products['ProductID']; ?>">                    
            <input class="btn" type="submit" name="submit" value="Add to Cart">                       
            </form>
        </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- dishes section ends -->

<!-- about section starts  -->

<section class="about" id="about">

    <h3 class="sub-heading"> about us </h3>
    <h1 class="heading"> why choose us? </h1>

    <div class="row">

        <div class="image">
            <img src="images/sabaw sa kanin.png" alt="">
        </div>

        <div class="content">
            <h3>Delicious Food at an Affordable Price</h3>
            <p>We offer high-quality food for everyone's enjoyment. Rest assured that your contentment will be fulfilled.</p>
            <p>Great quality food to enjoy especially by students which are near our establishment.</p>
            <div class="icons-container">
                <div class="icons">
                    <i class="fas fa-dollar-sign"></i>
                    <span> Cash On Delivery Only</span>
                </div>
                <div class="icons">
                    <i class="fas fa-headset"></i>
                    <span>08am - 10pm service</span>
                </div>
            </div>
            <a href="#" class="btn">learn more</a>
        </div>

    </div>

</section>

<!-- about section ends -->

<!-- menu section starts  -->

<section class="menu" id="menu">

    <h3 class="sub-heading"> our menu </h3>
    <h1 class="heading"> today's speciality </h1>

    <div class="box-container">
        <?php $query =  $db -> query('SELECT * FROM specialty');
        $products = $query -> fetch_all(MYSQLI_ASSOC);
        ?>
        <?php foreach($products as $special): ?>
        <div class="box">  
            <form action="addtocart.php" method="POST">     
            <div class="image">
                <img src='<?php echo $special['Image']; ?>'/>
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3><?= $special['Product_Name']?></h3>
                <p><?= $special['Message']?></p>
                <span class="price">₱<?= $special['Price']?></span><br>
                <input class="btn" type="hidden" name="id" value="<?php echo $special['ProductID']; ?>">                    
                <input class="btn" type="submit" name="submits" value="Add to Cart">   
            </div>
            </form>    
        </div>
        <?php endforeach ?>
    </div>

</section>

<!-- menu section ends -->
                            
<!-- order section starts  -->

<section class="order" id="order">

    <h3 class="sub-heading"> order now </h3>
    <h1 class="heading"> free and fast </h1>

    <form action="orderproc.php" method="POST">

        <div class="inputBox">
            <div class="input">
                <span>your name</span>
                <input type="text" name="customername" placeholder="enter your name">
            </div>
            <div class="input">
                <span>your number</span>
                <input type="number" name="contactnumber" placeholder="enter your number">
            </div>
        </div>
        <div class="inputBox">
            <div class="input">
                <span>your order</span>
                <input type="text" name="order" placeholder="enter food name">
            </div>
            <div class="input">
                <span>additional food</span>
                <input type="text" name="extrafood" placeholder="extra with food">
            </div>
        </div>
        <div class="inputBox">
            <div class="input">
            <span>Quantity</span>
                <input type="number" name="quantity" placeholder="how many orders">
            </div>
            <div class="input">
                <span>date and time</span>
                <input type="datetime-local" name="date">
            </div>
        </div>
        <div class="inputBox">
            <div class="input">
                <span>your address</span>
                <textarea name="address" placeholder="enter your address" id="" cols="30" rows="10"></textarea>
            </div>
            <div class="input">
                <span>your message</span>
                <textarea name="message" placeholder="enter your message" id="" cols="30" rows="10"></textarea>
            </div>
        </div>
        <input type="submit"  name="submits" value="order now" class="btn">

    </form>

</section>

<!-- order section ends -->

<!-- footer section starts  -->

<section class="footer">

    <div class="box-container">

        <div class="box">
            <h3>locations</h3>
            <a href="#">butong</a>
            <a href="#">muzon</a>
            <a href="#">kumintang</a>
            <a href="#">taal</a>
            <a href="#">balagtas</a>
        </div>

        <div class="box">
            <h3>quick links</h3>
            <a href="#">home</a>
            <a href="#">dishes</a>
            <a href="#">about</a>
            <a href="#">menu</a>
            <a href="#">reivew</a>
            <a href="#">order</a>
        </div>

        <div class="box">
            <h3>contact info</h3>
            <a href="#">09125398422</a>
            <a href="#">09758776327</a>
            <a href="#">ajahlyns_eatery@gmail.com</a>
            <a href="#">ajahlynseatery@gmail.com</a>
            <a href="#">Golden Country Homes, Brgy. Alangilan, Batangas City 4200</a>
        </div>

        <div class="box">
            <h3>follow us</h3>
            <a href="#">facebook</a>
            <a href="#">twitter</a>
            <a href="#">instagram</a>
            <a href="#">linkedin</a>
        </div>

    </div>

    <div class="credit"> copyright @ 2022 by <span>QWERTY</span> </div>

</section>

<!-- footer section ends -->

<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="script.js"></script>

</body>
</html>