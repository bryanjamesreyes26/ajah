<?php
include('connect.php');

if(isset($_POST['submit'])) {
    $ID = $_POST['id'];
    $query = "SELECT * FROM popular WHERE ProductID = '$ID'";
    $result = mysqli_query($db,$query);
    $row = mysqli_fetch_array($result);
    if($row) {
        $productname = $row['Product_Name'];
        $price = $row['Price'];
        $img = $row['Image'];
        $query = "INSERT INTO carts (ProductName, Price, Image) VALUES ('$productname', '$price', '$img')";   
        $result = mysqli_query($db,$query);

        if($result) {
            header("Location: index.php");
        }
        else {
            echo 'NO RESULT';
        }
    }
    else {
        echo 'NO RESULT';
    }
}

if(isset($_POST['submits'])) {
    $ID = $_POST['id'];
    $query = "SELECT * FROM specialty WHERE ProductID = '$ID'";
    $result = mysqli_query($db,$query);
    $row = mysqli_fetch_array($result);
    if($row) {
        $productname = $row['Product_Name'];
        $price = $row['Price'];
        $img = $row['Image'];
        $query = "INSERT INTO carts (ProductName, Price, Image) VALUES ('$productname', '$price', '$img')";   
        $result = mysqli_query($db,$query);

        if($result) {
            header("Location: index.php");
        }
        else {
            echo 'NO RESULT';
        }
    }
    else {
        echo 'NO RESULT';
    }
}