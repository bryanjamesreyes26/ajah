<?php 
include('connect.php');

if(isset($_POST['submit'])) {
    $cartID = $_POST['id'];
    $result = mysqli_query($db, "DELETE FROM carts where CartID = '$cartID'");
    if($result == true) {
        header('location: index.php');
    }
}
if(isset($_POST['submits'])) {
    $ordID = $_POST['id'];
    $result = mysqli_query($db, "DELETE FROM orders where OrderID= '$ordID'");
    if($result == true) {
        header('location: cart.php');
    }
}
?>